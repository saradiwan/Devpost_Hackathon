"""DesalGuard demo API: synthetic telemetry anomaly scoring with Isolation Forest."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sklearn.ensemble import IsolationForest
import numpy as np

app = FastAPI(title="DesalGuard ML API", version="1.1.0", description="Simulation-only anomaly scoring API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# Synthetic baseline only. Replace with validated, authorized data before any real deployment.
rng = np.random.default_rng(41)
normal = np.column_stack([rng.normal(5.15, .22, 1600), rng.normal(128, 7, 1600), rng.normal(420, 28, 1600)])
model = IsolationForest(n_estimators=120, contamination=0.035, random_state=41)
model.fit(normal)

class Telemetry(BaseModel):
    pressure: float = Field(ge=0, le=30)
    flow: float = Field(ge=0, le=1000)
    salinity: float = Field(ge=0, le=10000)
    timestamp: str | None = None

@app.get("/health")
def health():
    return {"status": "ok", "model": "IsolationForest", "data": "synthetic baseline"}

@app.post("/predict")
def predict(d: Telemetry):
    features = np.array([[d.pressure, d.flow, d.salinity]])
    # sklearn decision_function is higher for inliers; invert and normalize for an intuitive anomaly score.
    raw = float(model.decision_function(features)[0])
    score = float(np.clip(0.5 - raw, 0, 1))
    anomaly = bool(model.predict(features)[0] == -1)
    return {"anomaly": anomaly, "score": round(score, 4), "prediction": "ANOMALY" if anomaly else "NORMAL", "model": "IsolationForest", "timestamp": d.timestamp, "note": "An anomaly is not proof of a cyberattack."}
