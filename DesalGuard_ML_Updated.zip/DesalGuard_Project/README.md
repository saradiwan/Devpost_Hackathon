# DesalGuard — ML-powered water infrastructure security demo

A dark-themed, responsive dashboard for a hackathon prototype that monitors **synthetic** desalination telemetry and scores incoming readings with an Isolation Forest model.

## Run the dashboard (no backend required)

Open `index.html` in a browser. The UI uses a labelled browser statistical fallback when the Python API is not running. The attack button injects synthetic out-of-range readings. Export report downloads a JSON report.

## Run with the real ML backend

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload --host 127.0.0.1 --port 8000
```

Keep the API terminal open, then open `index.html`. The dashboard attempts `http://127.0.0.1:8000/predict` for every new reading. Check `http://127.0.0.1:8000/health` to verify the API. The model is trained on generated baseline samples at startup; this is an educational demo, not a validated industrial model.

## Demo flow

1. Open dashboard and wait for readings and ML scores.
2. Start the backend if you want Isolation Forest inference; otherwise the UI labels its fallback mode.
3. Click **Simulate attack scenario** to shift synthetic pressure, flow, and salinity readings.
4. Observe score, status, sensor table, and event timeline.
5. Click **Reset demo** to return to baseline telemetry.
6. Export a JSON report for your presentation.

## Important limitations and safety

- All data is synthetic. Do not connect this prototype to a live water plant, PLC, SCADA system, or industrial network.
- An anomaly is not necessarily malicious; maintenance, operating changes, or sensor faults can also cause unusual readings.
- The model's scores and threshold are demo-oriented. Evaluate false positives/negatives on authorized representative data before making security claims.
- This project is a proof of concept, not a production OT security product. It has no authentication, persistence, or production hardening by design.
